import type { LucideIcon } from "lucide-react";

export type UsaIconName =
  | "award"
  | "book"
  | "briefcase"
  | "check"
  | "clock"
  | "dollar"
  | "file"
  | "flag"
  | "globe"
  | "graduation"
  | "heart"
  | "home"
  | "hospital"
  | "map"
  | "plane"
  | "scale"
  | "shield"
  | "stethoscope"
  | "star"
  | "users";

export type UsaReason = {
  title: string;
  body: string;
  icon: UsaIconName;
};

export type UsaRequirement = {
  number: string;
  title: string;
  body: string;
  details: string[];
  icon: UsaIconName;
};

export type UsaStage = {
  number: number;
  title: string;
  timeframe: string;
  body: string;
  actions: string[];
  checkpoint: string;
};

export type UsaSalaryBand = {
  role: string;
  typical: string;
  note: string;
};

export type UsaHospital = {
  name: string;
  city: string;
  body: string;
  image: string;
  url: string;
};

export const usaPathway = {
  reasons: [
    {
      title: "High earning potential",
      body: "The United States is known for strong physician earning potential. Residency is paid employment, while attending compensation varies substantially by specialty, location, practice model, call, and benefits.",
      icon: "dollar",
    },
    {
      title: "Leading hospitals and technology",
      body: "The country is home to globally respected academic medical centers, advanced diagnostics, complex-care programs, and research environments such as Cleveland Clinic, Mayo Clinic, and Johns Hopkins.",
      icon: "hospital",
    },
    {
      title: "Globally respected training",
      body: "U.S. medical education, USMLE examinations, and ACGME-accredited residency training are widely recognized. Recognition is not automatic everywhere, so always check the rules of the country where you later want to work.",
      icon: "globe",
    },
    {
      title: "Freedom and opportunity",
      body: "As you put it: America, baby. The USA offers a large health system, many specialties, research opportunities, entrepreneurship, and different regional lifestyles—but access depends on exams, visas, finances, and competitiveness.",
      icon: "flag",
    },
  ] satisfies UsaReason[],
  requirements: [
    {
      number: "Step 1",
      title: "Choose your entry route and verify your school",
      body: "Start by deciding whether you will attend a U.S. medical school or qualify as an international medical graduate (IMG). The paperwork, exams, costs, and application strategy are different.",
      details: [
        "College route: complete a bachelor’s degree or required pre-med coursework, build a strong science foundation, sit the MCAT, and apply to U.S. MD or DO programs.",
        "IMG route: complete an eligible medical degree, confirm that your school appears in the World Directory of Medical Schools with the required ECFMG Sponsor Note, and create the relevant ECFMG/MyIntealth account.",
        "Prepare identity documents, diploma and transcript records, translations where needed, and primary-source verification. Keep names and dates consistent across every document.",
        "Plan early for finances, exam scheduling, travel, immigration status, and the state or programs where you may eventually train. Individual programs can add requirements beyond national rules.",
      ],
      icon: "file",
    },
    {
      number: "Step 2",
      title: "Complete USMLE and ECFMG certification requirements",
      body: "For the current IMG pathway, ECFMG states that applicants must pass USMLE Step 1 and Step 2 CK and complete the applicable clinical and communication requirements, including OET Medicine for Pathways applicants.",
      details: [
        "Register for and pass USMLE Step 1 and Step 2 Clinical Knowledge (CK), then protect enough preparation time to build a competitive and sustainable application rather than rushing every exam together.",
        "Complete the applicable ECFMG Pathway for clinical and communication skills. ECFMG’s current 2027 Pathways page says OET Medicine is required for all Pathways applicants, with no exception based on native language or citizenship.",
        "Track expiration dates, score-report rules, document verification, and the ECFMG Certification deadline for the Match cycle you intend to enter.",
        "Before applying, confirm the exact year-specific requirements with ECFMG and the NRMP. Certification is required to begin ACGME-accredited residency training as an IMG.",
      ],
      icon: "check",
    },
  ] satisfies UsaRequirement[],
  stages: [
    {
      number: 1,
      title: "College and pre-med foundation",
      timeframe: "Usually 4 years for a bachelor’s degree",
      body: "If you are starting from college in the United States, choose a degree plan that lets you complete medical-school prerequisites and develop the academic, clinical, service, and communication record expected by medical schools. Major choice can vary; the required coursework and readiness for the MCAT matter more than a particular major title.",
      actions: [
        "Complete biology, chemistry, physics, organic chemistry, writing, and other prerequisites required by target schools.",
        "Build patient-facing exposure, service, shadowing, research, leadership, and a record of reliable teamwork.",
        "Prepare for the MCAT and apply broadly to schools whose mission, cost, and admissions requirements fit your profile.",
      ],
      checkpoint: "You have a verified academic record, a realistic school list, meaningful clinical exposure, and an admissions plan.",
    },
    {
      number: 2,
      title: "Medical school: MD, DO, or an international medical degree",
      timeframe: "Usually 4 years in the U.S.; varies internationally",
      body: "U.S. MD and DO students combine foundational science with clinical rotations and graduate ready to enter the U.S. residency application process. International students complete their medical degree abroad and later use the IMG route, which requires ECFMG certification before U.S. residency training.",
      actions: [
        "Use pre-clinical years to master core science and learn how U.S. clinical care is documented and coordinated.",
        "Use clinical rotations to test specialty interests, develop professional references, and understand team-based care.",
        "For IMGs, keep the medical school transcript, diploma, internship evidence, and identity records ready for verification.",
      ],
      checkpoint: "You have completed or are approaching completion of medical school and can document your education clearly.",
    },
    {
      number: 3,
      title: "USMLE, English, and ECFMG preparation",
      timeframe: "Plan across medical school and the application year",
      body: "IMGs should treat ECFMG certification as a project with several dependencies: school eligibility and verification, USMLE Step 1 and Step 2 CK, the applicable Pathway, OET Medicine, and year-specific deadlines. U.S. graduates follow their school’s verification and examination timetable.",
      actions: [
        "Create an exam calendar and budget for registration, preparation, travel, and possible retakes.",
        "Complete the ECFMG requirements that apply to your Match year rather than relying on an old checklist.",
        "Keep copies of every confirmation, score report, and verified credential.",
      ],
      checkpoint: "Your credentials and examination requirements are complete or on a documented schedule that meets the Match deadline.",
    },
    {
      number: 4,
      title: "U.S. clinical experience and application portfolio",
      timeframe: "Often several months; varies by applicant and specialty",
      body: "Clinical exposure in the United States can help applicants understand local documentation, communication, patient-safety expectations, and team culture. Programs vary in what they accept, and clinical experience does not guarantee an interview or Match result.",
      actions: [
        "Seek legitimate clinical experiences that match your training level and preserve patient privacy.",
        "Develop a clear CV, personal statement, specialty strategy, and strong letters of recommendation.",
        "Research program requirements, visa policies, graduation-year preferences, and IMG policies before applying.",
      ],
      checkpoint: "Your application tells a consistent story about readiness, specialty fit, clinical growth, and professionalism.",
    },
    {
      number: 5,
      title: "ERAS application, interviews, and NRMP Match",
      timeframe: "One annual application and Match cycle",
      body: "Residency applicants submit applications through ERAS where applicable, interview with programs, and submit a rank-order list. The NRMP Main Residency Match provides the matching process, but applicants must satisfy Match and program eligibility requirements by the relevant deadlines.",
      actions: [
        "Submit complete, accurate documents and monitor every program’s specific instructions.",
        "Prepare for interviews around clinical reasoning, communication, ethics, teamwork, and your reasons for choosing the specialty.",
        "Review visa sponsorship and start-date requirements before ranking programs.",
      ],
      checkpoint: "You have a verified application, a realistic rank list, and a plan for the Match result or an alternative cycle.",
    },
    {
      number: 6,
      title: "Residency and state licensing",
      timeframe: "Usually 3–7 years depending on specialty",
      body: "Residency is paid graduate medical education in an ACGME-accredited program. Residents work under supervision, develop specialty competence, and complete program and state requirements. The exact license pathway differs by state and by applicant history.",
      actions: [
        "Complete orientation, training milestones, evaluations, and any remaining USMLE or state requirements.",
        "Build habits that protect patient safety: escalation, documentation, handoffs, feedback, and continuous learning.",
        "Plan early for fellowship, an attending position, or another approved career route.",
      ],
      checkpoint: "You have completed residency requirements and are eligible for the next step under the relevant state and specialty rules.",
    },
    {
      number: 7,
      title: "Fellowship, attending practice, or another medical career",
      timeframe: "Optional fellowship commonly adds 1–3 years",
      body: "After residency, physicians may practice as attendings, pursue subspecialty fellowship, enter research or education, work in public health, or develop health-technology and administrative careers. Visa, credentialing, and state licensure continue to matter after residency.",
      actions: [
        "Compare specialty demand, lifestyle, compensation, geography, and long-term professional goals.",
        "Complete hospital credentialing, malpractice and employment review, and state-specific licensing tasks.",
        "Maintain board, continuing education, and immigration compliance as applicable.",
      ],
      checkpoint: "Your post-residency plan is aligned with specialty qualifications, work authorization, licensure, and the life you want outside medicine.",
    },
  ] satisfies UsaStage[],
  advantages: [
    "Large and diverse health system with many specialties, subspecialties, academic centers, community hospitals, and research environments.",
    "Paid residency employment with structured graduate medical education and a wide range of training programs.",
    "Strong exposure to advanced technology, multidisciplinary teams, clinical trials, and complex-care systems.",
    "High physician earning potential, especially after training, with substantial variation by specialty, setting, and geography.",
    "Many possible professional directions beyond routine clinical work, including research, education, administration, public health, and health technology.",
    "A large country with different cities, climates, communities, and lifestyles, allowing physicians to search for a personal and professional fit.",
  ],
  disadvantages: [
    "The pathway is expensive and competitive: exams, applications, travel, clinical experiences, relocation, and immigration can require significant savings.",
    "Residency is demanding, with long shifts, night work, emotional load, and limited control over schedule during training.",
    "IMG applicants may face additional screening, fewer interview opportunities, graduation-year preferences, and specialty-specific competition.",
    "Visa sponsorship and work authorization can narrow the list of eligible programs and affect long-term planning.",
    "Health care costs, housing, transport, insurance, childcare, and student debt differ sharply by state and city.",
    "Recognition of U.S. credentials is broad but not automatic worldwide; another country may require its own licensing exams or supervised practice.",
  ],
  salaryBands: [
    { role: "Resident / PGY-1", typical: "$68,166 average stipend", note: "2025 nationwide unweighted average reported from the AAMC survey." },
    { role: "Resident / PGY-2", typical: "$70,499 average stipend", note: "Program year two average; benefits, taxes, and local cost of living affect take-home value." },
    { role: "Resident / PGY-3", typical: "$73,301 average stipend", note: "Program year three average; individual programs and regions vary." },
    { role: "Resident / PGY-4", typical: "$77,593 average stipend", note: "Program year four average; some specialties continue beyond four years." },
    { role: "Resident / PGY-5 to PGY-8", typical: "$81,807–$94,215 average stipend", note: "2025 AAMC averages across later program years and fellowship years." },
    { role: "Physician / attending", typical: "$239,200 or more median wage", note: "BLS reports a 2024 median wage equal to or greater than this threshold; specialty and practice model matter." },
  ] satisfies UsaSalaryBand[],
  lifestyleCards: [
    {
      title: "Work–life balance",
      body: "Balance depends heavily on specialty, practice setting, seniority, call, location, and personal boundaries. Residency commonly has demanding schedules; later outpatient, academic, hospital, part-time, or telehealth roles can offer different patterns.",
      icon: "clock" as UsaIconName,
    },
    {
      title: "Life outside medicine",
      body: "The USA offers major cities, small towns, national parks, beaches, mountains, cultural communities, sports, and many education options. The trade-off is that housing, transportation, health insurance, and childcare can be expensive in high-opportunity areas.",
      icon: "home" as UsaIconName,
    },
    {
      title: "Community and opportunity",
      body: "A large immigrant and international community can make relocation easier, while professional networks, conferences, research groups, and mentors can open doors. Building a support system matters as much as building a CV.",
      icon: "users" as UsaIconName,
    },
  ],
  hospitals: [
    {
      name: "Cleveland Clinic",
      city: "Cleveland, Ohio",
      body: "A major academic medical center known for complex-care services, specialty institutes, research, and a large integrated health system.",
      image: "/manus-storage/cleveland-clinic_79763ab6.jpg",
      url: "https://my.clevelandclinic.org/",
    },
    {
      name: "Mayo Clinic",
      city: "Rochester, Minnesota",
      body: "A physician-led academic health system with a strong focus on integrated care, specialty practice, education, and research.",
      image: "/manus-storage/mayo-clinic_81c4eaae.jpg",
      url: "https://www.mayoclinic.org/",
    },
    {
      name: "Johns Hopkins Medicine",
      city: "Baltimore, Maryland",
      body: "An academic medicine network associated with advanced clinical care, medical education, biomedical research, and innovation.",
      image: "/manus-storage/johns-hopkins_c2f88b0.jpg",
      url: "https://www.hopkinsmedicine.org/",
    },
  ] satisfies UsaHospital[],
  sources: [
    { label: "ECFMG — Requirements for 2027 Pathways for ECFMG Certification", url: "https://www.ecfmg.org/certification-pathways/" },
    { label: "NRMP — Are You Eligible?", url: "https://www.nrmp.org/residency-applicants/get-ready-for-the-match/are-you-eligible/" },
    { label: "BLS — Physicians and Surgeons Occupational Outlook", url: "https://www.bls.gov/ooh/healthcare/physicians-and-surgeons.htm" },
    { label: "AMA — Resident physician pay and 2025 AAMC stipend data", url: "https://www.ama-assn.org/medical-residents/residency-life/resident-physician-pay-still-rising-growth-trails-inflation" },
    { label: "USMLE — United States Medical Licensing Examination", url: "https://www.usmle.org/" },
    { label: "ACGME — Common Program Requirements", url: "https://www.acgme.org/programs-and-institutions/programs/common-program-requirements/" },
  ],
} as const;

export type UsaPathway = typeof usaPathway;
export type UsaIconMap = Record<UsaIconName, LucideIcon>;
