import {
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  BookOpen,
  Briefcase,
  Building2,
  CheckCircle2,
  Clock3,
  DollarSign,
  FileCheck2,
  Flag,
  Globe2,
  GraduationCap,
  HeartPulse,
  Home,
  MapPin,
  Plane,
  Scale,
  ShieldCheck,
  Star,
  Stethoscope,
  Users,
} from "lucide-react";
import { usaPathway, type UsaIconMap } from "../data/usaPathway";

const ICONS: UsaIconMap = {
  award: BadgeCheck,
  book: BookOpen,
  briefcase: Briefcase,
  check: CheckCircle2,
  clock: Clock3,
  dollar: DollarSign,
  file: FileCheck2,
  flag: Flag,
  globe: Globe2,
  graduation: GraduationCap,
  heart: HeartPulse,
  home: Home,
  hospital: Building2,
  map: MapPin,
  plane: Plane,
  scale: Scale,
  shield: ShieldCheck,
  stethoscope: Stethoscope,
  star: Star,
  users: Users,
};

function SectionHeading({ eyebrow, title, body }: { eyebrow: string; title: string; body?: string }) {
  return (
    <div className="max-w-3xl">
      <div className="eyebrow">{eyebrow}</div>
      <h2 className="mt-1 text-2xl font-extrabold tracking-tight sm:text-3xl">{title}</h2>
      {body ? <p className="mt-3 text-sm leading-6 text-muted-foreground">{body}</p> : null}
    </div>
  );
}

function IconBox({ name, className = "" }: { name: keyof typeof ICONS; className?: string }) {
  const Icon = ICONS[name];
  return (
    <div className={`grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-secondary text-primary ${className}`}>
      <Icon size={19} />
    </div>
  );
}

export default function UsaPathway() {
  return (
    <div className="space-y-10">
      <section className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
        <div className="grid lg:grid-cols-[1.05fr_0.95fr]">
          <div className="relative min-h-[330px] overflow-hidden bg-[#0b2d55]">
            <img
              src="/manus-storage/usa-flag_6f0fe36a.jpg"
              alt="United States flag waving in the sky"
              className="absolute inset-0 h-full w-full object-cover opacity-75"
            />
            <div className="absolute inset-0 bg-gradient-to-tr from-[#071b34]/90 via-[#0b2d55]/35 to-[#b22234]/45" />
            <div className="absolute inset-x-0 bottom-0 p-6 text-white sm:p-8">
              <div className="text-xs font-extrabold uppercase tracking-[0.22em] text-white/75">USA pathway</div>
              <h2 className="mt-2 max-w-xl text-3xl font-extrabold tracking-tight sm:text-4xl">
                Big opportunity. Big preparation. One detailed route.
              </h2>
              <p className="mt-3 max-w-xl text-sm leading-6 text-white/85">
                From college and medical school to USMLE, ECFMG certification, residency, and life as a physician in the United States.
              </p>
            </div>
          </div>
          <div className="flex flex-col justify-center p-6 sm:p-8">
            <div className="eyebrow">Why choose the USA?</div>
            <p className="mt-3 text-sm leading-6 text-muted-foreground">
              The USA combines high physician earning potential, globally respected hospitals, advanced technology, a wide specialty ecosystem, and many different ways to build a life. It is also expensive, competitive, and highly regulated—so the opportunity is real, but the preparation must be real too.
            </p>
            <div className="mt-6 flex flex-wrap gap-2">
              <a href="#usa-route" className="btn-primary inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-xs">
                See the full route <ArrowRight size={14} />
              </a>
              <a href="#usa-salary" className="btn-quiet inline-flex items-center gap-2 rounded-lg px-4 py-2.5 text-xs font-bold">
                Salary and life <DollarSign size={14} />
              </a>
            </div>
            <div className="mt-6 flex items-center gap-3 rounded-xl border border-[#d9b4b7] bg-[#fff7f7] p-3">
              <img
                src="/manus-storage/usa-reaction_54e666b4.gif"
                alt="User-supplied celebratory reaction GIF"
                className="h-16 w-20 shrink-0 rounded-lg object-cover"
              />
              <div>
                <p className="text-xs font-extrabold text-[#8b2332]">The energy</p>
                <p className="mt-1 text-xs leading-5 text-muted-foreground">
                  “Because it’s America, baby”—keep the ambition, then follow the checklist.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>

      <section aria-labelledby="why-usa-heading">
        <SectionHeading
          eyebrow="01 / The case for the USA"
          title="Four reasons applicants look toward the United States"
          body="These are compelling reasons to consider the USA, but none replaces a realistic plan for examinations, certification, finances, visa status, and specialty competitiveness."
        />
        <div id="why-usa-heading" className="mt-5 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {usaPathway.reasons.map((reason) => (
            <article key={reason.title} className="rounded-2xl border border-border bg-card p-5 shadow-sm transition-transform duration-200 hover:-translate-y-0.5">
              <IconBox name={reason.icon} />
              <h3 className="mt-4 text-base font-extrabold">{reason.title}</h3>
              <p className="mt-2 text-sm leading-6 text-muted-foreground">{reason.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section id="usa-requirements" aria-labelledby="usa-requirements-heading">
        <SectionHeading
          eyebrow="02 / Requirements"
          title="Start with the two decisions that shape everything else"
          body="The first steps are not just paperwork. They determine which examinations, credentials, costs, deadlines, and application strategy apply to you."
        />
        <div id="usa-requirements-heading" className="mt-5 grid gap-5 lg:grid-cols-2">
          {usaPathway.requirements.map((requirement) => (
            <article key={requirement.number} className="rounded-2xl border border-border bg-card p-6 shadow-sm">
              <div className="flex items-start gap-4">
                <IconBox name={requirement.icon} className="bg-[#e8f0ff] text-[#1d4ed8]" />
                <div>
                  <div className="eyebrow">{requirement.number}</div>
                  <h3 className="mt-1 text-lg font-extrabold">{requirement.title}</h3>
                  <p className="mt-3 text-sm leading-6 text-muted-foreground">{requirement.body}</p>
                </div>
              </div>
              <div className="mt-5 space-y-3 border-t border-border pt-5">
                {requirement.details.map((detail) => (
                  <div key={detail} className="flex items-start gap-2.5 text-sm leading-6">
                    <CheckCircle2 size={15} className="mt-1 shrink-0 text-primary" />
                    <span>{detail}</span>
                  </div>
                ))}
              </div>
            </article>
          ))}
        </div>
      </section>

      <section id="usa-route" aria-labelledby="usa-route-heading">
        <SectionHeading
          eyebrow="03 / The full pathway"
          title="From college to a medical career in the USA"
          body="There are two broad starting points: the U.S. college-to-medical-school route and the international medical graduate route. The stages below show where they meet and where IMGs have additional certification work."
        />
        <div id="usa-route-heading" className="mt-6 space-y-5">
          {usaPathway.stages.map((stage) => (
            <article key={stage.number} className="route-step rounded-2xl border border-border bg-card p-5 pl-14 shadow-sm sm:p-6 sm:pl-16">
              <span className="step-dot !top-6 !left-5">{stage.number}</span>
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div>
                  <h3 className="text-lg font-extrabold">{stage.title}</h3>
                  <p className="mt-1 text-xs font-bold uppercase tracking-wider text-primary">{stage.timeframe}</p>
                </div>
                {stage.number === 1 ? <GraduationCap size={22} className="text-primary" /> : null}
                {stage.number === 3 ? <ShieldCheck size={22} className="text-primary" /> : null}
                {stage.number === 5 ? <Stethoscope size={22} className="text-primary" /> : null}
              </div>
              <p className="mt-3 text-sm leading-6 text-muted-foreground">{stage.body}</p>
              <div className="mt-5 grid gap-4 lg:grid-cols-[1fr_0.75fr]">
                <div className="space-y-2.5">
                  {stage.actions.map((action) => (
                    <div key={action} className="flex items-start gap-2.5 text-sm leading-6">
                      <ArrowRight size={15} className="mt-1 shrink-0 text-primary" />
                      <span>{action}</span>
                    </div>
                  ))}
                </div>
                <div className="rounded-xl bg-secondary/60 p-4">
                  <p className="text-[11px] font-extrabold uppercase tracking-wider text-primary">Checkpoint</p>
                  <p className="mt-2 text-sm leading-6">{stage.checkpoint}</p>
                </div>
              </div>
            </article>
          ))}
        </div>
      </section>

      <section aria-labelledby="usa-tradeoffs-heading">
        <SectionHeading
          eyebrow="04 / Trade-offs"
          title="Advantages and disadvantages"
          body="The USA can be an exceptional fit for an ambitious applicant who is prepared for a long, expensive, competitive process. The same features that create opportunity can also create pressure."
        />
        <div id="usa-tradeoffs-heading" className="mt-5 grid gap-5 lg:grid-cols-2">
          <div className="rounded-2xl border border-[#b8dccf] bg-[#f3fbf7] p-6">
            <div className="flex items-center gap-2 text-[#267a5b]"><CheckCircle2 size={18} /><h3 className="text-base font-extrabold">Advantages</h3></div>
            <ul className="mt-5 space-y-3">
              {usaPathway.advantages.map((item) => <li key={item} className="flex items-start gap-2.5 text-sm leading-6"><CheckCircle2 size={15} className="mt-1 shrink-0 text-[#267a5b]" />{item}</li>)}
            </ul>
          </div>
          <div className="rounded-2xl border border-[#e6c39b] bg-[#fff9f0] p-6">
            <div className="flex items-center gap-2 text-[#ad6a16]"><Scale size={18} /><h3 className="text-base font-extrabold">Disadvantages</h3></div>
            <ul className="mt-5 space-y-3">
              {usaPathway.disadvantages.map((item) => <li key={item} className="flex items-start gap-2.5 text-sm leading-6"><Scale size={15} className="mt-1 shrink-0 text-[#ad6a16]" />{item}</li>)}
            </ul>
          </div>
        </div>
      </section>

      <section id="usa-salary" aria-labelledby="usa-salary-heading">
        <SectionHeading
          eyebrow="05 / Salary and lifestyle"
          title="Salary is strong, but the numbers need context"
          body="Residency salaries are stipends for supervised training, not attending compensation. Physician pay varies by specialty, geography, practice setting, schedule, benefits, taxes, and debt."
        />
        <div id="usa-salary-heading" className="mt-5 overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
          <div className="overflow-x-auto">
            <table className="w-full min-w-[640px] text-left text-sm">
              <thead className="bg-secondary/70 text-xs uppercase tracking-wider text-muted-foreground">
                <tr>
                  <th className="px-5 py-4 font-extrabold">Role</th>
                  <th className="px-5 py-4 font-extrabold">Typical figure</th>
                  <th className="px-5 py-4 font-extrabold">Context</th>
                </tr>
              </thead>
              <tbody>
                {usaPathway.salaryBands.map((band) => (
                  <tr key={band.role} className="border-t border-border align-top">
                    <td className="px-5 py-4 font-extrabold">{band.role}</td>
                    <td className="px-5 py-4 font-bold text-primary">{band.typical}</td>
                    <td className="px-5 py-4 leading-6 text-muted-foreground">{band.note}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <p className="border-t border-border bg-secondary/40 px-5 py-4 text-xs leading-5 text-muted-foreground">
            Salary figures are general orientation, not a promise of earnings. The resident figures reflect the 2025 AAMC survey as reported by the AMA; the attending figure is the BLS 2024 median-wage threshold for physicians and surgeons.
          </p>
        </div>

        <div className="mt-6 grid gap-4 md:grid-cols-3">
          {usaPathway.lifestyleCards.map((card) => {
            const Icon = ICONS[card.icon];
            return (
              <article key={card.title} className="rounded-2xl border border-border bg-card p-6 shadow-sm">
                <IconBox name={card.icon} />
                <h3 className="mt-4 text-base font-extrabold">{card.title}</h3>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{card.body}</p>
                <Icon size={15} className="mt-5 text-primary/60" />
              </article>
            );
          })}
        </div>
      </section>

      <section aria-labelledby="usa-hospitals-heading">
        <SectionHeading
          eyebrow="06 / A look at leading institutions"
          title="Hospitals that represent the USA’s academic medicine ecosystem"
          body="Cleveland Clinic, Mayo Clinic, and Johns Hopkins Medicine are examples of prominent U.S. academic health systems. They are not the only strong institutions, and seeing their names does not imply that admission, employment, or training is guaranteed."
        />
        <div id="usa-hospitals-heading" className="mt-5 grid gap-5 lg:grid-cols-3">
          {usaPathway.hospitals.map((hospital) => (
            <article key={hospital.name} className="overflow-hidden rounded-2xl border border-border bg-card shadow-sm">
              <div className="relative h-48 overflow-hidden bg-secondary">
                <img src={hospital.image} alt={`${hospital.name} hospital campus`} className="h-full w-full object-cover" loading="lazy" />
                <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-black/60 to-transparent p-4 pt-12 text-white">
                  <p className="text-xs font-bold uppercase tracking-wider text-white/80">{hospital.city}</p>
                </div>
              </div>
              <div className="p-5">
                <h3 className="text-base font-extrabold">{hospital.name}</h3>
                <p className="mt-2 text-sm leading-6 text-muted-foreground">{hospital.body}</p>
                <a href={hospital.url} target="_blank" rel="noreferrer" className="mt-4 inline-flex items-center gap-1.5 text-xs font-bold text-primary hover:underline">
                  Visit official site <ArrowUpRight size={13} />
                </a>
              </div>
            </article>
          ))}
        </div>
        <div className="mt-5 flex flex-wrap items-center gap-3 rounded-xl border border-[#c9d6e8] bg-[#f4f8ff] p-4 text-xs leading-5 text-muted-foreground">
          <Flag size={16} className="shrink-0 text-[#b22234]" />
          <span>USA visual theme: stars, stripes, ambition, and a pathway that rewards preparation.</span>
          <Plane size={16} className="shrink-0 text-primary" />
          <span>Verify image permissions before publishing outside this editable project.</span>
        </div>
      </section>

      <section aria-labelledby="usa-sources-heading">
        <SectionHeading
          eyebrow="Official sources"
          title="Check the current rules before you apply"
          body="Requirements, deadlines, exams, visa policies, and program eligibility can change. Use these links as starting points and confirm details directly with the responsible organization."
        />
        <div id="usa-sources-heading" className="mt-5 grid gap-3 sm:grid-cols-2">
          {usaPathway.sources.map((source) => (
            <a key={source.url} href={source.url} target="_blank" rel="noreferrer" className="group flex items-center justify-between gap-3 rounded-xl border border-border bg-background p-4 text-sm font-bold transition-colors hover:border-primary/40 hover:bg-secondary/50">
              <span>{source.label}</span>
              <ArrowUpRight size={15} className="shrink-0 text-primary transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
            </a>
          ))}
        </div>
        <p className="mt-5 rounded-lg bg-secondary/60 p-3 text-xs leading-5 text-muted-foreground">
          For education only. This guide is not immigration, legal, financial, or medical advice. “Globally respected” does not mean universally accepted, and salary, licensing, visa, and recognition outcomes vary by case, specialty, state, and destination country.
        </p>
      </section>
    </div>
  );
}
